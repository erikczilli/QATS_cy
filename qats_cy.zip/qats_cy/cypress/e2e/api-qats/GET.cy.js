describe('API Test Automation', ()=>{
    it('GET - List Users', ()=>{
        cy.request('GET', 'https://reqres.in/api/users?page=2').then((response) => {
            
            expect(response.body.total).to.equal(12)
            expect(response.body.data[0].last_name).to.equal('Lawson') 
            expect(response.body.data[1].last_name).to.equal('Ferguson') 
            expect(response.body.data.length).to.equal(response.body.total)
        })
    })

})


