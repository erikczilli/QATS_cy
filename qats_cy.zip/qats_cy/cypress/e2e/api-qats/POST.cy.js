const { random } = require("lodash")
const now = require("performance-now")

describe('API Test Automation',()=>{

    it('POST - Create', ()=>{

        cy.request('POST', 'https://reqres.in/api/users', {
            
            "name": "Juraj", 
            "job": "Janosik",
            "id": random,
            "createdAt": now
            }).then(function(response)
    {
    expect(response.status).to.equal(201)
    expect(response.body).to.have.property('createdAt')
    expect(response.body).to.have.property('id')   
    expect(response.duration).to.not.be.greaterThan(100) 
    })
    })

})